$(document).ready(function () {
    'use strict';

    $(".content .cont ul li").click(function () {
         
   });
    
});