<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>الملاعب</title>
        <link rel="stylesheet" href="<?php echo e(url('pg/css/pg.css')); ?>"/>
        <style type="text/css">
        @font-face{
            font-family:Jazeel-Bold;
            src:url('<?php echo e(url("pg/Fonts/Jazeel-Bold.otf")); ?>');
        }

        @font-face{
            font-family:SOGAND;
            src:url('<?php echo e(url("pg/Fonts/SOGAND.ttf")); ?>');
        }

        @font-face{
            font-family:VIP-Hala-Bold;
            src:url('<?php echo e(url("pg/Fonts/VIP-Hala-Bold.otf")); ?>');
        }
        </style>
    </head>
    <body>
<!-- ----------------------------------------- Starting Header ---------------------------------------------- !-->
        <header>
            <header>
            <ul class="right">
                <a href="" style="color: #fff"><li>الدورات</li></a>
                <a href="" style="color: #fff"><li class="active">الملاعب</li></a>
                <a href="/home" style="color: #fff"><li>الرئيسيه</li></a>
            </ul>
            <div class="left">
                <img src="<?php echo e(url('pg/images/headerlogo.png')); ?>"/>
            </div>
        </header>
        </header>
<!-- ----------------------------------------- Ending Header ---------------------------------------------- !-->

        
<!-- ----------------------------------------- Starting body ---------------------------------------------- !-->

        <section class="content">
            <div class="cont">
                <ul>
                    <?php $__currentLoopData = $pgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <img src="uploads/<?php echo e($pg->profile_image); ?>"/>
                            <p class="arabic"><?php echo e($pg->name); ?></p>
                            <p class="arabic"><?php echo e($pg->region); ?></p>
                            <p class="arabic">day Price: <?php echo e($pg->day_price); ?></p>
                            <p class="arabic">night Price: <?php echo e($pg->night_price); ?></p>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                    
                    
                </ul>
            
                
            </div>
        
        </section>

<!-- ----------------------------------------- Ending body ---------------------------------------------- !-->

    
        
        
        
        <script src="<?php echo e(url('pg/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(url('pg/js/pg-plugins.js')); ?>"></script>
    </body>
    
</html>