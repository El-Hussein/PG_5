<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>اسم الملعب</title>
        <link href="css/css/fontawesome-all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/pg-owner-style.css"/>
        
    </head>
    <body>
        
        <br/>
        <br/>
          <p class="arabic" style="font-size: 50px;font-family: VIP-Hala-Bold">اضافة حجز بتاريخ</p>
        
        <div class="tb2">
            <table class="arabic" style="border: 1px solid #000;text-align: center;width: 100%;">
                
                <tr>
                    <td>التاريخ</td>
                    <td>الساعه</td>
                    <td>المده</td>
                    <td>الاسم</td>
                    <td>الرقم</td>
                    <td>اضافه</td>
                </tr>
            
                
                <tr>
                    <td>
                        <select>
                        <optgroup label="التاريخ" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                                <option value="11">11</option>
                                <option value="12">12</option>
                                <option value="13">13</option>
                                <option value="14">14</option>
                                <option value="15">15</option>
                                <option value="16">16</option>
                                <option value="17">17</option>
                                <option value="18">18</option>
                                <option value="19">19</option>
                                <option value="20">20</option>
                                <option value="21">21</option>
                                <option value="20">22</option>
                                <option value="23">23</option>
                                <option value="24">24</option>
                                <option value="25">25</option>
                                <option value="26">26</option>
                                <option value="27">27</option>
                                <option value="28">28</option>
                                <option value="29">29</option>
                                <option value="30">30</option>
                            </select>
                    </td>
                    <td>
                        <select>
                                <option value="12">12:00 pm</option>
                                <option value="12.5">12:30 pm</option>
                                <option value="13">1:00 pm</option>
                                <option value="13.5">1:30 pm</option>
                                <option value="14">2:00 pm</option>
                                <option value="14.5">2:30 pm</option>
                                <option value="15">3:00 pm</option>
                                <option value="15.5">3:30 pm</option>
                                <option value="16">4:00 pm</option>
                                <option value="16.5">4:30 pm</option>
                                <option value="17">5:00 pm</option>
                                <option value="17.5">5:30 pm</option>
                                <option value="18">6:00 pm</option>
                                <option value="18.5">6:30 pm</option>
                                <option value="19">7:00 pm</option>
                                <option value="19.5">7:30 pm</option>
                                <option value="20">8:00 pm</option>
                                <option value="20.5">8:30 pm</option>
                                <option value="21">9:00 pm</option>
                                <option value="21.5">9:30 pm</option>
                                <option value="22">10:00 pm</option>
                                <option value="22.5">10:30 pm</option>
                                <option value="23">11:00 pm</option>
                                <option value="23.5">11:30 pm</option>
                                <option value="24">12:00 am</option>
                                <option value="24.5">12:30 am</option>
                                <option value="1">1:00 am</option>
                                <option value="1.5">1:30 am</option>
                                <option value="2">2:00 am</option>
                                <option value="2.5">2:30 am</option>
                                <option value="3">3:00 am</option>
                                <option value="3.5">3:30 am</option>
                                <option value="4">4:00 am</option>
                                <option value="4.5">4:30 am</option>
                                <option value="5">5:00 am</option>
                                <option value="5.5">5:30 am</option>
                                <option value="6">6:00 am</option>

                            </select>
                    </td>
                    <td>
                        <select>
                                <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                            </select>
                    </td>
                    <td><input type="text"/></td>
                    <td><input type="text"/></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                
            </table>
        </div>
        
        <br/>
        <br/>
        <br/>
        <p class="arabic" style="font-size: 50px;font-family: VIP-Hala-Bold">حجوزات اليوم</p>
        <div class="tb">
            <table class="arabic" style="border: 1px solid #000;text-align: center;width: 100%;">
                <tr  >
                    <td>الساعه</td>
                    <td>المده</td>
                    <td>الاسم</td>
                    <td>الرقم</td>
                    <td>الغاء</td>
                </tr>
            
                
                <tr>
                    <td>1:00 pm</td>
                    <td>1 ساعه</td>
                    <td>roshdy32</td>
                    <td>01234567891</td>
                    <td id="cancel"><input type="button" value="X"/></td> 
                    <!-- هنا الزر دا لما يدوس عليه عايزين الحجز يتلغي و بعدين لو داس تاني يتعمل بلوك لصاحب الرقم من الحجز ع الملعب دا تاني !-->
                </tr>
                
                <tr>
                    <td>3:00 pm</td>
                    <td>1 ساعه</td>
                    <td>roshdy32</td>
                    <td>01234567891</td>
                    <td id="cancel"><input type="button" value="X"/></td> 
                </tr>
                
                <tr>
                    <td>5:00 pm</td>
                    <td>1 ساعه</td>
                    <td>roshdy32</td>
                    <td>01234567891</td>
                    <td id="cancel"><input type="button" value="X"/></td> 
                </tr>
                
                <tr>
                    <td>11:00 pm</td>
                    <td>1 ساعه</td>
                    <td>roshdy32</td>
                    <td>01234567891</td>
                    <td id="cancel"><input type="button" value="X"/></td> 
                </tr>
            </table>
        </div>
        
        <br/>
        <br/>
          <p class="arabic" style="font-size: 50px;font-family: VIP-Hala-Bold">الاوقات الفارغه</p>
        
        <div class="tb2">
            <table class="arabic" style="border: 1px solid #000;text-align: center;width: 100%;">
                <tr  >
                    <td>الساعه</td>
                    <td>المده</td>
                    <td>الاسم</td>
                    <td>الرقم</td>
                    <td>اضافه</td>
                </tr>
            
                
                <tr>
                    <td>12:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                
                
                <tr>
                    <td>2:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>4:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>6:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>7:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>8:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>9:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>10:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>11:00 pm</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>12:00 am</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>1:00 am</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>2:00 am</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>3:00 am</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>4:00 am</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>5:00 am</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                <tr>
                    <td>6:00 am</td>
                    <td>
                        <select>
                            <optgroup label="المده" style="background: #fff;color: #6e1bad"/>
                                <option value="1">1 ساعه</option>
                                <option value="2">2 ساعه</option>
                                <option value="3">3 ساعه</option>
                                <option value="4">4 ساعه</option>
                                <option value="5">5 ساعه</option>
                                <option value="6">6 ساعه</option>
                        
                        </select>
                    </td>
                    <td><input type="text" name="name"/></td>
                    <td><input type="text" name="number"></td>
                    <td><input type="button" value="اضافه"/></td>
                </tr>
                
                
                
                
            </table>
        </div>
        
        <br/>
        <br/>
        
        
        <br/>
        <br/>
          <p class="arabic" style="font-size: 50px;font-family: VIP-Hala-Bold">هذا الاسبوع</p>
        
        <div class="tb2">
            <table class="arabic" style="border: 1px solid #000;text-align: center;width: 100%;">
                <tr>
                    <td>التاريخ</td>
                    <td>الساعه</td>
                    <td>المده</td>
                    <td>الاسم</td>
                    <td>الرقم</td>
                    <td>الحاله</td>
                </tr>
        
                <tr>
                    <td>1/5</td>
                    <td>10:00 pm</td>
                    <td>1 ساعه</td>
                    <td>ziad1</td>
                    <td>0123456897</td>
                    <td>صحيح</td>
                </tr>
                
                <tr>
                    <td>1/5</td>
                    <td>10:00 pm</td>
                    <td>1 ساعه</td>
                    <td>ziad2</td>
                    <td>0123456897</td>
                    <td>صحيح</td>
                </tr>
                
                <tr>
                    <td>1/5</td>
                    <td>11:00 pm</td>
                    <td>2 ساعه</td>
                    <td>ziad3</td>
                    <td>0123456897</td>
                    <td>صحيح</td>
                </tr>
                
                <tr>
                    <td>1/5</td>
                    <td>10:00 pm</td>
                    <td>1 ساعه</td>
                    <td>ziad4</td>
                    <td>0123456897</td>
                    <td>صحيح</td>
                </tr>
                
                <tr>
                    <td>1/5</td>
                    <td>10:00 pm</td>
                    <td>1 ساعه</td>
                    <td>ziad5</td>
                    <td>0123456897</td>
                    <td>صحيح</td>
                </tr>
                
            </table>
        
        </div>
        <br/>
        <br/>
        <br/>
        <br/>
         <div class="tb2">
            <table class="arabic" style="border: 1px solid #000;text-align: center;width: 100%;">
                
                <tr>
                    <td>اجمالي الحجوزات</td>
                    <td>عدد الحجوزات<br/> من صاحب الملعب</td>
                    <td>عدد الحجوزات <br/>من الموقع</td>
                    <td>النسبه المستحقه <br/>لكل حجز</td>
                    <td>المبلغ</td>
                </tr>
            
                
                <tr>
                    <td>35</td>
                    <td>10</td>
                    <td>25</td>
                    <td>10%</td>
                    <td>300</td>
                </tr>
                
                
            </table>
        </div>
        
        
        <br/>
        <br/>
          <p class="arabic" style="font-size: 50px;font-family: VIP-Hala-Bold">العناصر المحظوره</p>
        <div class="tb2">
            <table class="arabic" style="border: 1px solid #000;text-align: center;width: 100%;">
                
                <tr>
                    <td>الاسم</td>
                    <td>الرقم</td>
                </tr>
            
                
                <tr>
                    <td>Ziad</td>
                    <td>01234567891</td>
                </tr>
            </table>
        </div>
        
        
        
        <script src="js/jquery.min.js"></script>
        <script src="js/plugins.js"></script>
    </body>
    
    
</html>