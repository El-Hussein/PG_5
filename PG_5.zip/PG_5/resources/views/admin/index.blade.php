<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title>الصفحة الرئيسية</title>
</head>
<body>

<form style="float: right;">
	<br><input type="text" name="pg_name" required><label>:اسم الملعب </label>
	<br><input type="number" name="pg_price" required><label>:سعر الساعة </label>
	<br><input type="text" name="pg_lat" required><label>:خطوط الطول </label>
	<br><input type="text" name="pg_lng" required><label>:خطوط العرض </label>
	<br><input type="text" name="pg_img" required><label>:صوره المعلب </label>
	<br><input type="text" name="pg_username" required><label>:اسم المستخدم </label>
	<br><input type="password" name="pg_password" required><label>:الرقم السري </label>
</form>

</body>
</html>